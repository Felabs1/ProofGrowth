export type SubmissionStatus =
  | 'pending'
  | 'approved'
  | 'rejected'
  | 'revision_requested';

export interface Submission {
  id: string;
  competitionId: string;
  competitionTitle: string;
  participantName: string;
  participantWallet: string;
  submittedAt: string;
  summary: string;
  claimedMetric: string;
  evidence: string;
  evidenceUrl?: string;
  status: SubmissionStatus;
  pointsAwarded?: number;
  founderNote?: string;
}

export interface Competition {
  id: string;
  title: string;
  description: string;
  category: string;
  prizePool: number;
  startDate: string;
  endDate: string;
  daysLeft: number;
  participants: number;
  submissionsTotal: number;
  pendingReview: number;
  status: 'active' | 'ended' | 'upcoming';
  winners: number;
  goalType: 'users' | 'volume' | 'leads';
  instructions: string;
  proofRequirements: string[];
  scoringRules: { label: string; points: number }[];
  leaderboard: {
    rank: number;
    name: string;
    pts: number;
    approvedSubmissions: number;
    wallet: string;
  }[];
  progress: number;
  founderWallet: string;
}

export interface Participant {
  rank: number;
  name: string;
  wallet: string;
  pts: number;
  wins: number;
  delta: number;
  competitions: number;
  earned: number;
}

export const MY_PARTICIPANT = {
  name: 'Bob M.',
  wallet: 'GCD34…7A2B',
  initials: 'BM',
};

/** Mock logged-in founder — owns comp-1 and comp-3 */
export const MY_FOUNDER = {
  name: 'Alex R.',
  wallet: 'GFOUND…SAAS',
  initials: 'AR',
};

export const FOUNDER_COMPETITION_IDS = ['comp-1', 'comp-3'] as const;

export function isFounderCompetition(competitionId: string): boolean {
  return (FOUNDER_COMPETITION_IDS as readonly string[]).includes(competitionId);
}

export function getFounderCompetitions(): Competition[] {
  return competitions.filter((c) => isFounderCompetition(c.id));
}

export const competitions: Competition[] = [
  {
    id: 'comp-1',
    title: 'Acquire 20 Active Users for SaaS Tool',
    description:
      'Drive high-quality user acquisition for our B2B project management SaaS. Submit proof from your campaign; we verify against our product analytics.',
    category: 'SaaS · User Acquisition',
    prizePool: 500,
    startDate: '2026-05-26',
    endDate: '2026-06-05',
    daysLeft: 3,
    participants: 34,
    submissionsTotal: 128,
    pendingReview: 7,
    status: 'active',
    winners: 3,
    progress: 68,
    goalType: 'users',
    founderWallet: 'GFOUND…SAAS',
    instructions:
      'Count only users who completed onboarding and used the core “create project” action within 7 days. Referral links must use your assigned UTM. Screenshots must show date range matching the competition window.',
    proofRequirements: [
      'UTM or referral link used',
      'Screenshot or export from your analytics',
      'List of user emails or IDs (anonymized OK)',
    ],
    scoringRules: [
      { label: 'Per approved signup', points: 1 },
      { label: 'Onboarding completed', points: 5 },
      { label: 'Core action in 7 days', points: 10 },
      { label: 'Return after 24h', points: 20 },
    ],
    leaderboard: [
      { rank: 1, name: 'Alice K.', pts: 248, approvedSubmissions: 12, wallet: 'GAB12…3F4E' },
      { rank: 2, name: 'Bob M.', pts: 213, approvedSubmissions: 9, wallet: 'GCD34…7A2B' },
      { rank: 3, name: 'Carlos R.', pts: 176, approvedSubmissions: 8, wallet: 'GEF56…9C3D' },
      { rank: 4, name: 'Diana W.', pts: 141, approvedSubmissions: 6, wallet: 'G1234…AB5C' },
      { rank: 5, name: 'Sam T.', pts: 98, approvedSubmissions: 4, wallet: 'G5678…DE6F' },
    ],
  },
  {
    id: 'comp-2',
    title: 'Drive Retention for Fintech App',
    description:
      'Maximize verified 7-day retention. Submit cohort proof; founder checks Mixpanel against your claims.',
    category: 'Fintech · Retention',
    prizePool: 1000,
    startDate: '2026-05-28',
    endDate: '2026-06-09',
    daysLeft: 7,
    participants: 78,
    submissionsTotal: 214,
    pendingReview: 14,
    status: 'active',
    winners: 5,
    progress: 42,
    goalType: 'users',
    founderWallet: 'GFOUND…FINT',
    instructions:
      'Users must complete KYC and link a bank account. Retention is measured at day 7 from first app open. Batch submissions weekly with cohort size stated clearly.',
    proofRequirements: [
      'Cohort size and date range',
      'Mixpanel/Amplitude screenshot or CSV export',
      'Optional: support ticket IDs for edge cases',
    ],
    scoringRules: [
      { label: 'KYC completed', points: 8 },
      { label: 'Bank linked', points: 12 },
      { label: 'First transaction', points: 25 },
      { label: 'Day-7 retention (approved)', points: 40 },
    ],
    leaderboard: [
      { rank: 1, name: 'Felix O.', pts: 412, approvedSubmissions: 18, wallet: 'GGH78…1B2C' },
      { rank: 2, name: 'Diana W.', pts: 362, approvedSubmissions: 15, wallet: 'G1234…AB5C' },
      { rank: 3, name: 'Sam T.', pts: 298, approvedSubmissions: 11, wallet: 'G5678…DE6F' },
    ],
  },
  {
    id: 'comp-3',
    title: 'B2B Lead Activation Sprint',
    description:
      'Generate qualified B2B leads. Submit demo requests and call attendance proof for founder review.',
    category: 'B2B · Lead Gen',
    prizePool: 750,
    startDate: '2026-05-29',
    endDate: '2026-06-07',
    daysLeft: 5,
    participants: 22,
    submissionsTotal: 67,
    pendingReview: 3,
    status: 'active',
    winners: 3,
    progress: 55,
    goalType: 'leads',
    founderWallet: 'GFOUND…CRM',
    instructions:
      'Leads must attend a 15-min discovery call and activate a trial. HubSpot deal links or calendar screenshots required.',
    proofRequirements: [
      'HubSpot/Salesforce deal link or lead email',
      'Calendar proof for calls attended',
    ],
    scoringRules: [
      { label: 'Demo request (approved)', points: 5 },
      { label: 'Call attended', points: 20 },
      { label: 'Trial activated', points: 50 },
    ],
    leaderboard: [
      { rank: 1, name: 'Carlos R.', pts: 320, approvedSubmissions: 7, wallet: 'GEF56…9C3D' },
      { rank: 2, name: 'Mei L.', pts: 280, approvedSubmissions: 6, wallet: 'G9012…GH7I' },
      { rank: 3, name: 'Bob M.', pts: 215, approvedSubmissions: 5, wallet: 'GCD34…7A2B' },
    ],
  },
  {
    id: 'comp-4',
    title: 'Mobile App Install & Activate',
    description:
      'Drive installs and first-session activation. Submit App Store campaign stats and activation screenshots.',
    category: 'Mobile · Activation',
    prizePool: 2000,
    startDate: '2026-06-01',
    endDate: '2026-06-15',
    daysLeft: 13,
    participants: 145,
    submissionsTotal: 89,
    pendingReview: 22,
    status: 'active',
    winners: 5,
    progress: 20,
    goalType: 'users',
    founderWallet: 'GFOUND…MOB',
    instructions:
      'Installs must complete onboarding and use a core feature within 48h. Use assigned campaign codes in submission notes.',
    proofRequirements: [
      'Campaign / invite code',
      'Firebase or App Store Connect export',
      'Activation funnel screenshot',
    ],
    scoringRules: [
      { label: 'Install (approved)', points: 2 },
      { label: 'Onboarding done', points: 8 },
      { label: 'Core feature in 48h', points: 15 },
    ],
    leaderboard: [
      { rank: 1, name: 'Felix O.', pts: 680, approvedSubmissions: 24, wallet: 'GGH78…1B2C' },
      { rank: 2, name: 'Alice K.', pts: 612, approvedSubmissions: 21, wallet: 'GAB12…3F4E' },
    ],
  },
  {
    id: 'comp-5',
    title: 'E-commerce Conversion Boost',
    description: 'Ended — winners paid from escrow after final founder review.',
    category: 'E-commerce · Conversion',
    prizePool: 1500,
    startDate: '2026-05-20',
    endDate: '2026-06-01',
    daysLeft: 0,
    participants: 89,
    submissionsTotal: 310,
    pendingReview: 0,
    status: 'ended',
    winners: 3,
    progress: 100,
    goalType: 'volume',
    founderWallet: 'GFOUND…DTC',
    instructions: 'First purchase and repeat within 14 days counted after Stripe reconciliation.',
    proofRequirements: ['Stripe dashboard export', 'Order IDs'],
    scoringRules: [
      { label: 'First purchase', points: 40 },
      { label: 'Repeat in 14d', points: 90 },
    ],
    leaderboard: [
      { rank: 1, name: 'Mei L.', pts: 920, approvedSubmissions: 14, wallet: 'G9012…GH7I' },
      { rank: 2, name: 'Alice K.', pts: 840, approvedSubmissions: 13, wallet: 'GAB12…3F4E' },
      { rank: 3, name: 'Bob M.', pts: 760, approvedSubmissions: 11, wallet: 'GCD34…7A2B' },
    ],
  },
  {
    id: 'comp-6',
    title: 'Web3 Wallet Onboarding',
    description: 'Upcoming — on-chain actions can be auto-scored; off-chain claims still need founder review.',
    category: 'Web3 · Onboarding',
    prizePool: 3000,
    startDate: '2026-06-10',
    endDate: '2026-06-24',
    daysLeft: 22,
    participants: 0,
    submissionsTotal: 0,
    pendingReview: 0,
    status: 'upcoming',
    winners: 5,
    progress: 0,
    goalType: 'volume',
    founderWallet: 'GFOUND…DEFI',
    instructions: 'Submit wallet addresses for swaps; founder verifies on Stellar explorer.',
    proofRequirements: ['Transaction hashes', 'Wallet list'],
    scoringRules: [
      { label: 'Wallet connected', points: 5 },
      { label: 'First swap (approved)', points: 30 },
    ],
    leaderboard: [],
  },
];

export const globalLeaderboard: Participant[] = [
  { rank: 1, name: 'Alice K.', wallet: 'GAB12…3F4E', pts: 1240, wins: 7, delta: 18, competitions: 12, earned: 4200 },
  { rank: 2, name: 'Bob M.', wallet: 'GCD34…7A2B', pts: 1180, wins: 5, delta: 12, competitions: 10, earned: 3100 },
  { rank: 3, name: 'Felix O.', wallet: 'GGH78…1B2C', pts: 1120, wins: 4, delta: 32, competitions: 9, earned: 2800 },
  { rank: 4, name: 'Diana W.', wallet: 'G1234…AB5C', pts: 980, wins: 3, delta: 8, competitions: 8, earned: 2200 },
  { rank: 5, name: 'Carlos R.', wallet: 'GEF56…9C3D', pts: 870, wins: 2, delta: -12, competitions: 7, earned: 1800 },
];

/** All submissions across founder-owned competitions */
export const founderSubmissions: Submission[] = [
  {
    id: 'sub-101',
    competitionId: 'comp-1',
    competitionTitle: 'Acquire 20 Active Users for SaaS Tool',
    participantName: 'Sam T.',
    participantWallet: 'G5678…DE6F',
    submittedAt: '2026-06-02 14:22',
    summary: 'Week 2 cohort — 4 new onboarded users from LinkedIn outreach',
    claimedMetric: '4 users · onboarding complete',
    evidence: 'Mixpanel cohort export + UTM link proof',
    evidenceUrl: 'https://example.com/proof/sam-week2',
    status: 'pending',
  },
  {
    id: 'sub-102',
    competitionId: 'comp-1',
    competitionTitle: 'Acquire 20 Active Users for SaaS Tool',
    participantName: 'Diana W.',
    participantWallet: 'G1234…AB5C',
    submittedAt: '2026-06-02 11:05',
    summary: 'Twitter thread campaign — 6 signups, 5 completed onboarding',
    claimedMetric: '5 onboarded users',
    evidence: 'Screenshots + anonymized user IDs CSV',
    status: 'pending',
  },
  {
    id: 'sub-103',
    competitionId: 'comp-3',
    competitionTitle: 'B2B Lead Activation Sprint',
    participantName: 'Mei L.',
    participantWallet: 'G9012…GH7I',
    submittedAt: '2026-06-02 09:40',
    summary: '3 demo calls attended, 2 trials activated',
    claimedMetric: '2 trials · 3 calls',
    evidence: 'HubSpot deal links + calendar invites',
    evidenceUrl: 'https://example.com/proof/mei-crm',
    status: 'pending',
  },
  {
    id: 'sub-104',
    competitionId: 'comp-1',
    competitionTitle: 'Acquire 20 Active Users for SaaS Tool',
    participantName: 'Carlos R.',
    participantWallet: 'GEF56…9C3D',
    submittedAt: '2026-05-31 09:18',
    summary: 'Newsletter blast — 8 signups claimed',
    claimedMetric: '8 signups',
    evidence: 'Mailchimp stats (only 3 matched in our analytics)',
    status: 'revision_requested',
    founderNote: 'Please resubmit with users that appear in our product DB. 3 of 8 matched.',
  },
  {
    id: 'sub-105',
    competitionId: 'comp-1',
    competitionTitle: 'Acquire 20 Active Users for SaaS Tool',
    participantName: 'Alice K.',
    participantWallet: 'GAB12…3F4E',
    submittedAt: '2026-06-02 08:00',
    summary: 'Paid ads week 1 — 7 signups, 6 onboarding complete',
    claimedMetric: '6 onboarded users',
    evidence: 'Google Ads export + product analytics',
    status: 'pending',
  },
  {
    id: 'sub-106',
    competitionId: 'comp-3',
    competitionTitle: 'B2B Lead Activation Sprint',
    participantName: 'Felix O.',
    participantWallet: 'GGH78…1B2C',
    submittedAt: '2026-06-02 07:15',
    summary: 'Outbound sequence — 4 demos booked, 2 attended',
    claimedMetric: '2 calls attended',
    evidence: 'Apollo sequence + Calendly screenshots',
    status: 'pending',
  },
  {
    id: 'sub-107',
    competitionId: 'comp-1',
    competitionTitle: 'Acquire 20 Active Users for SaaS Tool',
    participantName: 'Bob M.',
    participantWallet: 'GCD34…7A2B',
    submittedAt: '2026-06-02 08:15',
    summary: 'Reddit r/SaaS post — 5 signups claimed',
    claimedMetric: '5 signups',
    evidence: 'Post URL + signup export',
    status: 'pending',
  },
  {
    id: 'sub-108',
    competitionId: 'comp-3',
    competitionTitle: 'B2B Lead Activation Sprint',
    participantName: 'Diana W.',
    participantWallet: 'G1234…AB5C',
    submittedAt: '2026-06-01 14:00',
    summary: 'Partner webinar — 5 demo requests',
    claimedMetric: '5 demo requests',
    evidence: 'Zoom registration list + CRM import',
    status: 'pending',
  },
  {
    id: 'sub-109',
    competitionId: 'comp-1',
    competitionTitle: 'Acquire 20 Active Users for SaaS Tool',
    participantName: 'Alice K.',
    participantWallet: 'GAB12…3F4E',
    submittedAt: '2026-05-28 16:00',
    summary: 'Influencer shoutout — 12 signups, 9 activated',
    claimedMetric: '9 activated users',
    evidence: 'Influencer contract + cohort report',
    status: 'approved',
    pointsAwarded: 120,
    founderNote: 'Strong quality — approved full batch.',
  },
  {
    id: 'sub-110',
    competitionId: 'comp-1',
    competitionTitle: 'Acquire 20 Active Users for SaaS Tool',
    participantName: 'Felix O.',
    participantWallet: 'GGH78…1B2C',
    submittedAt: '2026-05-27 11:30',
    summary: 'Community launch — 3 users with core action',
    claimedMetric: '3 users',
    evidence: 'Discord analytics + PH link',
    status: 'approved',
    pointsAwarded: 55,
  },
  {
    id: 'sub-111',
    competitionId: 'comp-3',
    competitionTitle: 'B2B Lead Activation Sprint',
    participantName: 'Bob M.',
    participantWallet: 'GCD34…7A2B',
    submittedAt: '2026-05-30 15:00',
    summary: '2 discovery calls, 1 trial started',
    claimedMetric: '1 trial · 2 calls',
    evidence: 'Calendar + HubSpot',
    status: 'approved',
    pointsAwarded: 70,
  },
  {
    id: 'sub-112',
    competitionId: 'comp-3',
    competitionTitle: 'B2B Lead Activation Sprint',
    participantName: 'Sam T.',
    participantWallet: 'G5678…DE6F',
    submittedAt: '2026-05-29 10:00',
    summary: 'Cold email — 10 leads, 1 trial (claimed)',
    claimedMetric: '1 trial',
    evidence: 'Instantly export — trial not found in CRM',
    status: 'rejected',
    founderNote: 'Trial not activated in HubSpot; resubmit with deal link.',
  },
];

/** @deprecated use founderSubmissions */
export const reviewQueue = founderSubmissions;

export type ReviewTab = 'pending' | 'approved' | 'all';

export function filterFounderSubmissions(
  submissions: Submission[],
  opts: { competitionId?: string | null; tab?: ReviewTab },
): Submission[] {
  let list = submissions;
  if (opts.competitionId) {
    list = list.filter((s) => s.competitionId === opts.competitionId);
  }
  if (opts.tab === 'pending') {
    list = list.filter((s) => s.status === 'pending' || s.status === 'revision_requested');
  } else if (opts.tab === 'approved') {
    list = list.filter((s) => s.status === 'approved' || s.status === 'rejected');
  }
  return list;
}

export function countSubmissionsByStatus(
  submissions: Submission[],
  competitionId?: string | null,
): { pending: number; approved: number; rejected: number; total: number } {
  const list = competitionId
    ? submissions.filter((s) => s.competitionId === competitionId)
    : submissions;
  return {
    pending: list.filter((s) => s.status === 'pending' || s.status === 'revision_requested').length,
    approved: list.filter((s) => s.status === 'approved').length,
    rejected: list.filter((s) => s.status === 'rejected').length,
    total: list.length,
  };
}

/** Current user (Bob) submissions */
export const mySubmissions: Submission[] = [
  {
    id: 'sub-my-1',
    competitionId: 'comp-1',
    competitionTitle: 'Acquire 20 Active Users for SaaS Tool',
    participantName: MY_PARTICIPANT.name,
    participantWallet: MY_PARTICIPANT.wallet,
    submittedAt: '2026-06-01 10:30',
    summary: 'Product Hunt launch day — 3 users onboarded with core action',
    claimedMetric: '3 users',
    evidence: 'PH link + analytics screenshot',
    status: 'approved',
    pointsAwarded: 45,
    founderNote: 'Approved all 3 — strong activation quality.',
  },
  {
    id: 'sub-my-2',
    competitionId: 'comp-1',
    competitionTitle: 'Acquire 20 Active Users for SaaS Tool',
    participantName: MY_PARTICIPANT.name,
    participantWallet: MY_PARTICIPANT.wallet,
    submittedAt: '2026-06-02 08:15',
    summary: 'Reddit r/SaaS post — 5 signups claimed',
    claimedMetric: '5 signups',
    evidence: 'Post URL + signup export',
    status: 'pending',
  },
  {
    id: 'sub-my-3',
    competitionId: 'comp-3',
    competitionTitle: 'B2B Lead Activation Sprint',
    participantName: MY_PARTICIPANT.name,
    participantWallet: MY_PARTICIPANT.wallet,
    submittedAt: '2026-05-30 15:00',
    summary: '2 discovery calls, 1 trial started',
    claimedMetric: '1 trial · 2 calls',
    evidence: 'Calendar + HubSpot',
    status: 'approved',
    pointsAwarded: 70,
  },
  {
    id: 'sub-my-4',
    competitionId: 'comp-2',
    competitionTitle: 'Drive Retention for Fintech App',
    participantName: MY_PARTICIPANT.name,
    participantWallet: MY_PARTICIPANT.wallet,
    submittedAt: '2026-05-29 12:00',
    summary: 'Influencer promo — retention cohort',
    claimedMetric: '12 users day-7 retained',
    evidence: 'Influencer contract + Mixpanel (pending founder check)',
    status: 'rejected',
    founderNote: 'Cohort dates outside competition window.',
  },
];

export function submissionStatusStyle(status: SubmissionStatus): {
  bg: string;
  color: string;
  label: string;
} {
  switch (status) {
    case 'approved':
      return { bg: 'rgba(16,185,129,0.15)', color: 'var(--pg-green)', label: 'Approved' };
    case 'rejected':
      return { bg: 'rgba(239,68,68,0.12)', color: 'var(--pg-red)', label: 'Rejected' };
    case 'revision_requested':
      return { bg: 'rgba(245,158,11,0.12)', color: 'var(--pg-amber)', label: 'Needs revision' };
    default:
      return { bg: 'rgba(37,99,235,0.12)', color: 'var(--pg-accent-bright)', label: 'Pending review' };
  }
}
