import { useMemo } from 'react';
import {
  MY_FOUNDER,
  countSubmissionsByStatus,
  founderSubmissions,
  getFounderCompetitions,
} from '../data/mockData';

interface FounderDashboardProps {
  onNavigate: (page: string, id?: string, options?: { tab?: string }) => void;
}

export function FounderDashboard({ onNavigate }: FounderDashboardProps) {
  const myComps = getFounderCompetitions();
  const totals = useMemo(() => countSubmissionsByStatus(founderSubmissions), []);

  const compRows = useMemo(
    () =>
      myComps.map((c) => ({
        ...c,
        counts: countSubmissionsByStatus(founderSubmissions, c.id),
      })),
    [myComps],
  );

  return (
    <div className="pg-page" style={{ maxWidth: 1200, margin: '0 auto', padding: '100px 2rem 60px' }}>
      <span
        style={{
          fontFamily: "'JetBrains Mono', monospace",
          fontSize: 11,
          color: 'var(--pg-accent-bright)',
          textTransform: 'uppercase',
          letterSpacing: '0.12em',
          display: 'block',
          marginBottom: '1rem',
        }}
      >
        // FOUNDER DASHBOARD
      </span>

      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: '2rem',
          flexWrap: 'wrap',
          gap: '1rem',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '1.25rem' }}>
          <div
            style={{
              width: 56,
              height: 56,
              borderRadius: '50%',
              background: 'var(--pg-accent-dim)',
              border: '2px solid var(--pg-border)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontFamily: "'JetBrains Mono', monospace",
              fontSize: 18,
              fontWeight: 700,
              color: 'var(--pg-accent-bright)',
            }}
          >
            {MY_FOUNDER.initials}
          </div>
          <div>
            <h1 style={{ fontSize: '1.5rem', fontWeight: 700, letterSpacing: '-0.02em', marginBottom: 4 }}>
              {MY_FOUNDER.name}
            </h1>
            <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, color: 'var(--pg-text-dim)' }}>
              {MY_FOUNDER.wallet} · Competition host
            </div>
          </div>
        </div>
        <button
          className="pg-btn-primary"
          style={{ padding: '12px 24px', fontSize: 14 }}
          onClick={() => onNavigate('review', undefined, { tab: 'pending' })}
        >
          Open full review queue ({totals.pending} pending)
        </button>
      </div>

      <div
        className="pg-grid-stats"
        style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '1rem', marginBottom: '2rem' }}
      >
        {[
          { label: 'Your competitions', value: myComps.length, color: 'var(--pg-text)' },
          { label: 'Pending review', value: totals.pending, color: 'var(--pg-amber)' },
          { label: 'Approved', value: totals.approved, color: 'var(--pg-green)' },
          { label: 'Total submissions', value: totals.total, color: 'var(--pg-accent-bright)' },
        ].map((s, i) => (
          <div
            key={i}
            style={{
              background: 'var(--pg-mid)',
              border: '1px solid var(--pg-border-dim)',
              borderRadius: 12,
              padding: '1.25rem',
            }}
          >
            <div
              style={{
                fontSize: 10,
                color: 'var(--pg-text-dim)',
                fontFamily: "'JetBrains Mono', monospace",
                textTransform: 'uppercase',
                letterSpacing: '0.08em',
                marginBottom: 6,
              }}
            >
              {s.label}
            </div>
            <div
              style={{
                fontSize: '2rem',
                fontWeight: 700,
                fontFamily: "'JetBrains Mono', monospace",
                color: s.color,
              }}
            >
              {s.value}
            </div>
          </div>
        ))}
      </div>

      <div style={{ marginBottom: '1rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <h2 style={{ fontSize: '1.25rem', fontWeight: 700 }}>Your competitions</h2>
        <button className="pg-btn-secondary" style={{ padding: '8px 16px', fontSize: 13 }} onClick={() => onNavigate('create')}>
          + New competition
        </button>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
        {compRows.map((c) => (
          <div
            key={c.id}
            style={{
              background: 'var(--pg-mid)',
              border: '1px solid var(--pg-border)',
              borderRadius: 14,
              padding: '20px 24px',
            }}
          >
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1.5rem', alignItems: 'flex-start', justifyContent: 'space-between' }}>
              <div style={{ flex: 1, minWidth: 240 }}>
                <div
                  style={{
                    fontSize: 10,
                    fontFamily: "'JetBrains Mono', monospace",
                    color: 'var(--pg-text-dim)',
                    textTransform: 'uppercase',
                    marginBottom: 6,
                  }}
                >
                  {c.category} · {c.status}
                </div>
                <div style={{ fontSize: 16, fontWeight: 600, marginBottom: 8, lineHeight: 1.4 }}>{c.title}</div>
                <div style={{ display: 'flex', gap: '1.5rem', flexWrap: 'wrap' }}>
                  <StatChip label="Prize" value={`${c.prizePool.toLocaleString()} USDC`} />
                  <StatChip label="Participants" value={String(c.participants)} />
                  <StatChip label="Submissions" value={String(c.counts.total)} />
                  <StatChip label="Pending" value={String(c.counts.pending)} highlight={c.counts.pending > 0} />
                </div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8, minWidth: 180 }}>
                <button
                  className="pg-btn-primary"
                  style={{ padding: '10px 18px', fontSize: 13, width: '100%' }}
                  onClick={() => onNavigate('review', c.id, { tab: 'pending' })}
                >
                  Review pending ({c.counts.pending})
                </button>
                <button
                  className="pg-btn-secondary"
                  style={{ padding: '10px 18px', fontSize: 13, width: '100%' }}
                  onClick={() => onNavigate('review', c.id, { tab: 'all' })}
                >
                  All submissions ({c.counts.total})
                </button>
                <button
                  style={{
                    padding: '8px 18px',
                    fontSize: 12,
                    background: 'none',
                    border: 'none',
                    color: 'var(--pg-text-sec)',
                    cursor: 'pointer',
                    fontFamily: "'JetBrains Mono', monospace",
                  }}
                  onClick={() => onNavigate('detail', c.id)}
                >
                  View competition page →
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div
        style={{
          marginTop: '2rem',
          padding: '1.25rem',
          background: 'var(--pg-surface)',
          border: '1px solid var(--pg-border-dim)',
          borderRadius: 12,
        }}
      >
        <div
          style={{
            fontSize: 11,
            fontFamily: "'JetBrains Mono', monospace",
            color: 'var(--pg-text-dim)',
            marginBottom: 8,
          }}
        >
          TIP
        </div>
        <p style={{ fontSize: 13, color: 'var(--pg-text-sec)', lineHeight: 1.6, margin: 0 }}>
          Use <strong style={{ color: 'var(--pg-text)' }}>Review queue</strong> to work through every pending submission across
          competitions, or open a single competition above to focus on one inbox.
        </p>
      </div>
    </div>
  );
}

function StatChip({
  label,
  value,
  highlight,
}: {
  label: string;
  value: string;
  highlight?: boolean;
}) {
  return (
    <div>
      <div style={{ fontSize: 10, color: 'var(--pg-text-dim)', fontFamily: "'JetBrains Mono', monospace", textTransform: 'uppercase' }}>
        {label}
      </div>
      <div
        style={{
          fontSize: 14,
          fontWeight: 700,
          fontFamily: "'JetBrains Mono', monospace",
          color: highlight ? 'var(--pg-amber)' : 'var(--pg-text)',
        }}
      >
        {value}
      </div>
    </div>
  );
}
