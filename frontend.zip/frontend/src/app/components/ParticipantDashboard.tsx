import { useMemo } from 'react';
import {
  competitions,
  globalLeaderboard,
  mySubmissions,
  MY_PARTICIPANT,
  submissionStatusStyle,
} from '../data/mockData';

interface ParticipantDashboardProps {
  onNavigate: (page: string, id?: string) => void;
}

const myCompetitions = [
  { ...competitions[0], myScore: 213, myRank: 2, pendingSubs: 1 },
  { ...competitions[1], myScore: 198, myRank: 5, pendingSubs: 0 },
  { ...competitions[3], myScore: 612, myRank: 2, pendingSubs: 0 },
];

export function ParticipantDashboard({ onNavigate }: ParticipantDashboardProps) {
  const me = globalLeaderboard[1];
  const approvedPts = useMemo(
    () => mySubmissions.filter((s) => s.status === 'approved').reduce((a, s) => a + (s.pointsAwarded ?? 0), 0),
    [],
  );
  const pendingCount = mySubmissions.filter((s) => s.status === 'pending').length;

  return (
    <div className="pg-page" style={{ maxWidth: 1200, margin: '0 auto', padding: '100px 2rem 60px' }}>
      <span
        style={{
          fontFamily: "'JetBrains Mono', monospace",
          fontSize: 11,
          color: 'var(--pg-accent-bright)',
          textTransform: 'uppercase',
          letterSpacing: '0.12em',
          display: 'block',
          marginBottom: '1rem',
        }}
      >
        // MY COMPETITIONS (PARTICIPANT)
      </span>

      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: '2rem',
          flexWrap: 'wrap',
          gap: '1rem',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '1.25rem' }}>
          <div
            style={{
              width: 56,
              height: 56,
              borderRadius: '50%',
              background: 'var(--pg-accent-dim)',
              border: '2px solid var(--pg-border)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontFamily: "'JetBrains Mono', monospace",
              fontSize: 18,
              fontWeight: 700,
              color: 'var(--pg-accent-bright)',
            }}
          >
            {MY_PARTICIPANT.initials}
          </div>
          <div>
            <h1 style={{ fontSize: '1.5rem', fontWeight: 700, letterSpacing: '-0.02em', marginBottom: 4 }}>{me.name}</h1>
            <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, color: 'var(--pg-text-dim)' }}>{me.wallet}</div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: '0.75rem' }}>
          <button className="pg-btn-secondary" style={{ padding: '10px 20px', fontSize: 13 }} onClick={() => onNavigate('browse')}>
            Browse Competitions
          </button>
        </div>
      </div>

      <div
        className="pg-grid-stats"
        style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '1rem', marginBottom: '2rem' }}
      >
        {[
          { label: 'Global Rank', value: `#${me.rank}`, color: 'var(--pg-accent-bright)', sub: 'Approved points across comps' },
          { label: 'Approved Points', value: approvedPts.toLocaleString(), color: 'var(--pg-green)', sub: 'From founder-approved subs' },
          { label: 'Pending Review', value: pendingCount, color: 'var(--pg-amber)', sub: 'Awaiting founder decision' },
          { label: 'USDC Earned', value: `$${me.earned.toLocaleString()}`, color: 'var(--pg-amber)', sub: 'Lifetime payouts' },
        ].map((s, i) => (
          <div
            key={i}
            style={{
              background: 'var(--pg-mid)',
              border: '1px solid var(--pg-border-dim)',
              borderRadius: 12,
              padding: '1.25rem',
            }}
          >
            <div
              style={{
                fontSize: 10,
                color: 'var(--pg-text-dim)',
                fontFamily: "'JetBrains Mono', monospace",
                textTransform: 'uppercase',
                letterSpacing: '0.08em',
                marginBottom: 6,
              }}
            >
              {s.label}
            </div>
            <div
              style={{
                fontSize: '2rem',
                fontWeight: 700,
                fontFamily: "'JetBrains Mono', monospace",
                lineHeight: 1,
                color: s.color,
                marginBottom: 4,
              }}
            >
              {s.value}
            </div>
            <div style={{ fontSize: 12, color: 'var(--pg-text-dim)' }}>{s.sub}</div>
          </div>
        ))}
      </div>

      <div className="pg-stack" style={{ display: 'grid', gridTemplateColumns: '1fr 380px', gap: '1.5rem', alignItems: 'start' }}>
        <div>
          <div
            style={{
              background: 'var(--pg-mid)',
              border: '1px solid var(--pg-border)',
              borderRadius: 14,
              overflow: 'hidden',
              marginBottom: '1.5rem',
            }}
          >
            <div
              style={{
                padding: '16px 20px',
                borderBottom: '1px solid var(--pg-border-dim)',
                background: 'var(--pg-surface)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}
            >
              <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, color: 'var(--pg-text-sec)' }}>
                ACTIVE COMPETITIONS
              </span>
              <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 11, color: 'var(--pg-text-dim)' }}>
                {myCompetitions.length} joined
              </span>
            </div>
            {myCompetitions.map((c, i) => (
              <div
                key={c.id}
                style={{
                  padding: '16px 20px',
                  borderBottom: i < myCompetitions.length - 1 ? '1px solid var(--pg-border-dim)' : 'none',
                  cursor: 'pointer',
                }}
                onClick={() => onNavigate('detail', c.id)}
              >
                <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 10 }}>
                  <div>
                    <div
                      style={{
                        fontSize: 10,
                        fontFamily: "'JetBrains Mono', monospace",
                        color: 'var(--pg-text-dim)',
                        textTransform: 'uppercase',
                        marginBottom: 4,
                      }}
                    >
                      {c.category}
                    </div>
                    <div style={{ fontSize: 14, fontWeight: 600, lineHeight: 1.4 }}>{c.title}</div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: 10, color: 'var(--pg-text-dim)', fontFamily: "'JetBrains Mono', monospace" }}>PRIZE</div>
                    <div
                      style={{
                        fontFamily: "'JetBrains Mono', monospace",
                        fontSize: 15,
                        fontWeight: 700,
                        color: 'var(--pg-accent-bright)',
                      }}
                    >
                      {c.prizePool.toLocaleString()} USDC
                    </div>
                  </div>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '1rem' }}>
                  <div>
                    <div style={{ fontSize: 10, color: 'var(--pg-text-dim)', fontFamily: "'JetBrains Mono', monospace", textTransform: 'uppercase', marginBottom: 2 }}>
                      Rank
                    </div>
                    <div
                      style={{
                        fontFamily: "'JetBrains Mono', monospace",
                        fontSize: 18,
                        fontWeight: 700,
                        color: c.myRank <= 3 ? '#FBBF24' : 'var(--pg-text)',
                      }}
                    >
                      #{c.myRank}
                    </div>
                  </div>
                  <div>
                    <div style={{ fontSize: 10, color: 'var(--pg-text-dim)', fontFamily: "'JetBrains Mono', monospace", textTransform: 'uppercase', marginBottom: 2 }}>
                      Approved pts
                    </div>
                    <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 18, fontWeight: 700 }}>{c.myScore}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: 10, color: 'var(--pg-text-dim)', fontFamily: "'JetBrains Mono', monospace", textTransform: 'uppercase', marginBottom: 2 }}>
                      Pending
                    </div>
                    <div
                      style={{
                        fontFamily: "'JetBrains Mono', monospace",
                        fontSize: 18,
                        fontWeight: 700,
                        color: c.pendingSubs > 0 ? 'var(--pg-amber)' : 'var(--pg-text-dim)',
                      }}
                    >
                      {c.pendingSubs}
                    </div>
                  </div>
                </div>
                <button
                  className="pg-btn-secondary"
                  style={{ marginTop: 12, padding: '8px 14px', fontSize: 12 }}
                  onClick={(e) => {
                    e.stopPropagation();
                    onNavigate('detail', c.id);
                  }}
                >
                  Submit proof →
                </button>
              </div>
            ))}
          </div>

          <div style={{ background: 'var(--pg-mid)', border: '1px solid var(--pg-border)', borderRadius: 14, overflow: 'hidden' }}>
            <div
              style={{
                padding: '16px 20px',
                borderBottom: '1px solid var(--pg-border-dim)',
                background: 'var(--pg-surface)',
              }}
            >
              <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, color: 'var(--pg-text-sec)' }}>
                MY SUBMISSIONS
              </span>
            </div>
            {mySubmissions.map((s, i) => {
              const st = submissionStatusStyle(s.status);
              return (
                <div
                  key={s.id}
                  style={{
                    padding: '14px 20px',
                    borderBottom: i < mySubmissions.length - 1 ? '1px solid var(--pg-border-dim)' : 'none',
                    cursor: 'pointer',
                  }}
                  onClick={() => onNavigate('detail', s.competitionId)}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
                    <span
                      style={{
                        fontSize: 10,
                        padding: '2px 6px',
                        borderRadius: 4,
                        fontWeight: 600,
                        background: st.bg,
                        color: st.color,
                        fontFamily: "'JetBrains Mono', monospace",
                      }}
                    >
                      {st.label.toUpperCase()}
                    </span>
                    <span style={{ fontSize: 11, color: 'var(--pg-text-dim)', fontFamily: "'JetBrains Mono', monospace" }}>
                      {s.submittedAt}
                    </span>
                    {s.pointsAwarded != null && (
                      <span style={{ marginLeft: 'auto', fontSize: 12, color: 'var(--pg-green)', fontFamily: "'JetBrains Mono', monospace", fontWeight: 700 }}>
                        +{s.pointsAwarded} pts
                      </span>
                    )}
                  </div>
                  <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 4 }}>{s.summary}</div>
                  <div style={{ fontSize: 12, color: 'var(--pg-text-dim)' }}>{s.competitionTitle}</div>
                </div>
              );
            })}
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <div style={{ background: 'var(--pg-mid)', border: '1px solid var(--pg-border)', borderRadius: 14, overflow: 'hidden' }}>
            <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--pg-border-dim)', background: 'var(--pg-surface)' }}>
              <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, color: 'var(--pg-text-sec)' }}>GLOBAL RANK</span>
            </div>
            <div style={{ padding: '1rem' }}>
              {globalLeaderboard.slice(0, 5).map((p, i) => {
                const isMe = p.name === me.name;
                return (
                  <div
                    key={p.rank}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 10,
                      padding: '8px',
                      borderRadius: 6,
                      background: isMe ? 'rgba(37,99,235,0.1)' : 'transparent',
                      marginBottom: 2,
                      border: isMe ? '1px solid var(--pg-border)' : '1px solid transparent',
                    }}
                  >
                    <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 11, color: i < 2 ? '#FBBF24' : 'var(--pg-text-dim)', width: 20 }}>
                      #{p.rank}
                    </span>
                    <span style={{ fontSize: 13, flex: 1, fontWeight: isMe ? 700 : 400 }}>
                      {p.name}
                      {isMe && ' (you)'}
                    </span>
                    <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, color: 'var(--pg-text-sec)' }}>{p.pts.toLocaleString()}</span>
                  </div>
                );
              })}
              <button
                className="pg-btn-secondary"
                style={{ width: '100%', padding: '9px', fontSize: 13, marginTop: '0.75rem' }}
                onClick={() => onNavigate('leaderboard')}
              >
                View leaderboard →
              </button>
            </div>
          </div>

          <div
            style={{
              background: 'var(--pg-accent-glow)',
              border: '1px solid var(--pg-border)',
              borderRadius: 14,
              padding: '1.25rem',
            }}
          >
            <div style={{ fontSize: 10, fontFamily: "'JetBrains Mono', monospace", color: 'var(--pg-text-dim)', textTransform: 'uppercase', marginBottom: 8 }}>
              HOW SCORING WORKS
            </div>
            <p style={{ fontSize: 13, color: 'var(--pg-text-sec)', lineHeight: 1.6, marginBottom: '1rem' }}>
              You submit proof of growth work. The competition founder reviews against their own analytics and awards points — the leaderboard only reflects approved submissions.
            </p>
            <button className="pg-btn-primary" style={{ width: '100%', padding: '10px', fontSize: 13 }} onClick={() => onNavigate('browse')}>
              Find a competition
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
