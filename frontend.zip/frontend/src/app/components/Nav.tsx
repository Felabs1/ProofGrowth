import { useState } from "react";
import { ConnectWallet } from "./ConnectWallet";
import { countSubmissionsByStatus, founderSubmissions } from "../data/mockData";

interface NavProps {
  currentPage: string;
  onNavigate: (page: string, id?: string, options?: { tab?: string }) => void;
}

export function Nav({ currentPage, onNavigate }: NavProps) {
  const [menuOpen, setMenuOpen] = useState(false);
  const pendingReview = countSubmissionsByStatus(founderSubmissions).pending;

  const go = (page: string) => {
    setMenuOpen(false);
    onNavigate(page);
  };

  return (
    <nav
      className="pg-nav"
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100,
        padding: "0 2rem",
        height: 64,
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        background: "rgba(5,8,22,0.92)",
        backdropFilter: "blur(16px)",
        borderBottom: "1px solid rgba(255,255,255,0.06)",
      }}
    >
      <button
        onClick={() => go("landing")}
        style={{
          fontFamily: "'Space Grotesk', sans-serif",
          fontWeight: 700,
          fontSize: 18,
          color: "#F0F4FF",
          background: "none",
          border: "none",
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          gap: 8,
        }}
      >
        <div
          style={{
            width: 8,
            height: 8,
            borderRadius: "50%",
            background: "#3B82F6",
            boxShadow: "0 0 8px #3B82F6",
          }}
          className="pg-pulse-dot"
        />
        ZaoTrak
      </button>

      <div className={`pg-nav-center ${menuOpen ? "open" : ""}`}>
        <button
          className={`pg-nav-link ${currentPage === "browse" ? "active" : ""}`}
          onClick={() => go("browse")}
        >
          Competitions
        </button>
        <button
          className={`pg-nav-link ${currentPage === "leaderboard" ? "active" : ""}`}
          onClick={() => go("leaderboard")}
        >
          Leaderboard
        </button>
        <button
          className={`pg-nav-link ${currentPage === "dashboard" ? "active" : ""}`}
          onClick={() => go("dashboard")}
        >
          My competitions
        </button>
        <button
          className={`pg-nav-link ${currentPage === "founder" ? "active" : ""}`}
          onClick={() => go("founder")}
        >
          Founder
        </button>
        <button
          className={`pg-nav-link ${currentPage === "review" ? "active" : ""}`}
          onClick={() => go("review", undefined, { tab: "pending" })}
          style={{ display: "flex", alignItems: "center", gap: 6 }}
        >
          Review queue
          {pendingReview > 0 && (
            <span
              style={{
                fontSize: 10,
                fontWeight: 700,
                padding: "1px 6px",
                borderRadius: 999,
                background: "var(--pg-amber)",
                color: "#0f172a",
                fontFamily: "'JetBrains Mono', monospace",
              }}
            >
              {pendingReview}
            </span>
          )}
        </button>
        <button
          className="pg-btn-primary pg-nav-menu-create"
          style={{ padding: "12px 20px", fontSize: 14 }}
          onClick={() => go("create")}
        >
          Create Competition
        </button>
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
        <button
          className="pg-btn-secondary pg-nav-create"
          style={{ padding: "8px 20px", fontSize: 14 }}
          onClick={() => go("create")}
        >
          Create Competition
        </button>
        <ConnectWallet />
        <button
          className="pg-nav-toggle"
          aria-label="Toggle menu"
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((o) => !o)}
        >
          {menuOpen ? "✕" : "☰"}
        </button>
      </div>
    </nav>
  );
}
