import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router';
import {
  filterFounderSubmissions,
  founderSubmissions,
  getFounderCompetitions,
  submissionStatusStyle,
  type ReviewTab,
  type Submission,
  type SubmissionStatus,
} from '../data/mockData';

interface FounderReviewProps {
  onNavigate: (page: string, id?: string, options?: { tab?: string }) => void;
}

const TABS: { id: ReviewTab; label: string }[] = [
  { id: 'pending', label: 'Pending' },
  { id: 'approved', label: 'Decided' },
  { id: 'all', label: 'All' },
];

export function FounderReview({ onNavigate }: FounderReviewProps) {
  const [searchParams, setSearchParams] = useSearchParams();
  const compFilter = searchParams.get('comp') || '';
  const tab = (searchParams.get('tab') as ReviewTab) || 'pending';

  const [queue, setQueue] = useState<Submission[]>(founderSubmissions);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [pointsInput, setPointsInput] = useState('40');
  const [note, setNote] = useState('');

  const filtered = useMemo(
    () =>
      filterFounderSubmissions(queue, {
        competitionId: compFilter || null,
        tab,
      }),
    [queue, compFilter, tab],
  );

  const pendingInView = filtered.filter(
    (s) => s.status === 'pending' || s.status === 'revision_requested',
  ).length;

  useEffect(() => {
    if (filtered.length === 0) {
      setSelectedId(null);
      return;
    }
    if (!selectedId || !filtered.some((s) => s.id === selectedId)) {
      setSelectedId(filtered[0].id);
    }
  }, [filtered, selectedId]);

  const selected = queue.find((s) => s.id === selectedId) ?? null;

  const setCompFilter = (id: string) => {
    const next = new URLSearchParams(searchParams);
    if (id) next.set('comp', id);
    else next.delete('comp');
    setSearchParams(next);
  };

  const setTab = (t: ReviewTab) => {
    const next = new URLSearchParams(searchParams);
    next.set('tab', t);
    setSearchParams(next);
  };

  const updateSubmission = (id: string, patch: Partial<Submission>) => {
    setQueue((q) => q.map((s) => (s.id === id ? { ...s, ...patch } : s)));
  };

  const act = (status: SubmissionStatus) => {
    if (!selected) return;
    const pts = status === 'approved' ? Number(pointsInput) || 0 : undefined;
    updateSubmission(selected.id, {
      status,
      pointsAwarded: pts,
      founderNote: note.trim() || selected.founderNote,
    });
    const remaining = filterFounderSubmissions(
      queue.map((s) =>
        s.id === selected.id
          ? { ...s, status, pointsAwarded: pts, founderNote: note.trim() || s.founderNote }
          : s,
      ),
      { competitionId: compFilter || null, tab },
    ).filter((s) => s.id !== selected.id && (s.status === 'pending' || s.status === 'revision_requested'));
    setSelectedId(remaining[0]?.id ?? null);
    setNote('');
  };

  const founderComps = getFounderCompetitions();
  const activeComp = compFilter ? founderComps.find((c) => c.id === compFilter) : null;

  return (
    <div className="pg-page" style={{ maxWidth: 1200, margin: '0 auto', padding: '100px 2rem 60px' }}>
      <button
        onClick={() => onNavigate('founder')}
        style={{
          background: 'none',
          border: 'none',
          color: 'var(--pg-text-sec)',
          cursor: 'pointer',
          fontFamily: "'JetBrains Mono', monospace",
          fontSize: 12,
          marginBottom: '1rem',
          display: 'flex',
          alignItems: 'center',
          gap: 6,
        }}
      >
        ← Founder dashboard
      </button>

      <span
        style={{
          fontFamily: "'JetBrains Mono', monospace",
          fontSize: 11,
          color: 'var(--pg-accent-bright)',
          textTransform: 'uppercase',
          letterSpacing: '0.12em',
          display: 'block',
          marginBottom: '1rem',
        }}
      >
        // REVIEW QUEUE
      </span>

      <div
        style={{
          display: 'flex',
          alignItems: 'flex-end',
          justifyContent: 'space-between',
          marginBottom: '1.25rem',
          flexWrap: 'wrap',
          gap: '1rem',
        }}
      >
        <div>
          <h1 style={{ fontSize: 'clamp(1.6rem, 3vw, 2.2rem)', fontWeight: 700, letterSpacing: '-0.02em', marginBottom: 8 }}>
            {activeComp ? 'Competition inbox' : 'All submissions'}
          </h1>
          <p style={{ fontSize: '0.95rem', color: 'var(--pg-text-sec)', maxWidth: 560, lineHeight: 1.6 }}>
            Showing <strong style={{ color: 'var(--pg-text)' }}>{filtered.length}</strong> of{' '}
            <strong style={{ color: 'var(--pg-text)' }}>{queue.length}</strong> submissions
            {compFilter ? ` for ${activeComp?.title ?? compFilter}` : ' across your competitions'}.
          </p>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <div
            style={{
              background: 'var(--pg-mid)',
              border: '1px solid var(--pg-border)',
              borderRadius: 12,
              padding: '10px 16px',
              textAlign: 'center',
            }}
          >
            <div style={{ fontSize: 10, color: 'var(--pg-text-dim)', fontFamily: "'JetBrains Mono', monospace" }}>IN VIEW</div>
            <div style={{ fontSize: 22, fontWeight: 700, fontFamily: "'JetBrains Mono', monospace" }}>{filtered.length}</div>
          </div>
          <div
            style={{
              background: 'var(--pg-mid)',
              border: '1px solid var(--pg-border)',
              borderRadius: 12,
              padding: '10px 16px',
              textAlign: 'center',
            }}
          >
            <div style={{ fontSize: 10, color: 'var(--pg-text-dim)', fontFamily: "'JetBrains Mono', monospace" }}>NEEDS ACTION</div>
            <div style={{ fontSize: 22, fontWeight: 700, fontFamily: "'JetBrains Mono', monospace", color: 'var(--pg-amber)' }}>
              {pendingInView}
            </div>
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem', marginBottom: '1.25rem', alignItems: 'center' }}>
        <select
          className="pg-select"
          style={{ maxWidth: 320 }}
          value={compFilter}
          onChange={(e) => setCompFilter(e.target.value)}
        >
          <option value="">All my competitions</option>
          {founderComps.map((c) => (
              <option key={c.id} value={c.id}>
                {c.title.slice(0, 42)}
                {c.title.length > 42 ? '…' : ''}
              </option>
            ))}
        </select>

        <div style={{ display: 'flex', gap: 6, background: 'var(--pg-surface)', borderRadius: 10, padding: 4 }}>
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              style={{
                padding: '8px 16px',
                fontSize: 13,
                fontWeight: 500,
                borderRadius: 7,
                cursor: 'pointer',
                border: 'none',
                background: tab === t.id ? 'var(--pg-accent)' : 'transparent',
                color: tab === t.id ? 'white' : 'var(--pg-text-sec)',
              }}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <div className="pg-stack" style={{ display: 'grid', gridTemplateColumns: 'minmax(280px, 360px) 1fr', gap: '1.5rem', alignItems: 'start' }}>
        <div
          style={{
            background: 'var(--pg-mid)',
            border: '1px solid var(--pg-border)',
            borderRadius: 14,
            overflow: 'hidden',
            maxHeight: '70vh',
            display: 'flex',
            flexDirection: 'column',
          }}
        >
          <div
            style={{
              padding: '14px 18px',
              borderBottom: '1px solid var(--pg-border-dim)',
              background: 'var(--pg-surface)',
              fontFamily: "'JetBrains Mono', monospace",
              fontSize: 12,
              color: 'var(--pg-text-sec)',
              flexShrink: 0,
            }}
          >
            SUBMISSIONS ({filtered.length})
          </div>
          <div style={{ overflowY: 'auto', flex: 1 }}>
            {filtered.length === 0 ? (
              <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--pg-text-dim)', fontSize: 13 }}>
                No submissions in this view. Try another tab or competition.
              </div>
            ) : (
              filtered.map((s) => {
                const st = submissionStatusStyle(s.status);
                const active = s.id === selectedId;
                return (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => setSelectedId(s.id)}
                    style={{
                      width: '100%',
                      textAlign: 'left',
                      padding: '14px 18px',
                      border: 'none',
                      borderBottom: '1px solid var(--pg-border-dim)',
                      cursor: 'pointer',
                      background: active ? 'rgba(37,99,235,0.1)' : 'transparent',
                      borderLeft: active ? '3px solid var(--pg-accent-bright)' : '3px solid transparent',
                    }}
                  >
                    {!compFilter && (
                      <div
                        style={{
                          fontSize: 10,
                          color: 'var(--pg-text-dim)',
                          fontFamily: "'JetBrains Mono', monospace",
                          marginBottom: 4,
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          whiteSpace: 'nowrap',
                        }}
                      >
                        {s.competitionTitle}
                      </div>
                    )}
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6, gap: 8 }}>
                      <span style={{ fontSize: 13, fontWeight: 600 }}>{s.participantName}</span>
                      <span
                        style={{
                          fontSize: 9,
                          padding: '2px 6px',
                          borderRadius: 4,
                          fontWeight: 600,
                          background: st.bg,
                          color: st.color,
                          fontFamily: "'JetBrains Mono', monospace",
                          flexShrink: 0,
                        }}
                      >
                        {st.label.toUpperCase()}
                      </span>
                    </div>
                    <div
                      style={{
                        fontSize: 11,
                        color: 'var(--pg-text-dim)',
                        fontFamily: "'JetBrains Mono', monospace",
                        marginBottom: 4,
                      }}
                    >
                      {s.submittedAt}
                    </div>
                    <div style={{ fontSize: 12, color: 'var(--pg-text-sec)', lineHeight: 1.4 }}>
                      {s.summary.length > 72 ? `${s.summary.slice(0, 72)}…` : s.summary}
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {selected ? (
          <div
            style={{
              background: 'var(--pg-mid)',
              border: '1px solid var(--pg-border)',
              borderRadius: 14,
              padding: '1.5rem',
            }}
          >
            <div style={{ marginBottom: '1.25rem' }}>
              <div style={{ fontSize: 11, fontFamily: "'JetBrains Mono', monospace", color: 'var(--pg-text-dim)', marginBottom: 6 }}>
                {selected.competitionTitle}
              </div>
              <h2 style={{ fontSize: '1.25rem', fontWeight: 700, marginBottom: 8 }}>{selected.participantName}</h2>
              <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, color: 'var(--pg-text-dim)' }}>
                {selected.participantWallet} · {selected.submittedAt}
              </div>
            </div>

            <DetailBlock label="Summary" value={selected.summary} />
            <DetailBlock label="Claimed outcome" value={selected.claimedMetric} highlight />
            <DetailBlock label="Evidence provided" value={selected.evidence} />
            {selected.evidenceUrl && (
              <a
                href={selected.evidenceUrl}
                target="_blank"
                rel="noreferrer"
                style={{ fontSize: 13, color: 'var(--pg-accent-bright)', fontFamily: "'JetBrains Mono', monospace" }}
              >
                Open evidence link →
              </a>
            )}

            {selected.founderNote && selected.status !== 'pending' && (
              <div
                style={{
                  marginTop: '1rem',
                  padding: '12px',
                  background: 'var(--pg-surface)',
                  borderRadius: 8,
                  border: '1px solid var(--pg-border-dim)',
                }}
              >
                <div style={{ fontSize: 10, color: 'var(--pg-text-dim)', fontFamily: "'JetBrains Mono', monospace", marginBottom: 4 }}>
                  FOUNDER NOTE
                </div>
                <div style={{ fontSize: 13, color: 'var(--pg-text-sec)' }}>{selected.founderNote}</div>
              </div>
            )}

            {(selected.status === 'pending' || selected.status === 'revision_requested') && (
              <>
                <div style={{ marginTop: '1.5rem' }}>
                  <label
                    style={{
                      display: 'block',
                      fontSize: 11,
                      color: 'var(--pg-text-dim)',
                      fontFamily: "'JetBrains Mono', monospace",
                      textTransform: 'uppercase',
                      marginBottom: 8,
                    }}
                  >
                    Points to award (if approved)
                  </label>
                  <input
                    className="pg-input"
                    type="number"
                    min={0}
                    value={pointsInput}
                    onChange={(e) => setPointsInput(e.target.value)}
                    style={{ maxWidth: 140 }}
                  />
                </div>
                <div style={{ marginTop: '1rem' }}>
                  <label
                    style={{
                      display: 'block',
                      fontSize: 11,
                      color: 'var(--pg-text-dim)',
                      fontFamily: "'JetBrains Mono', monospace",
                      textTransform: 'uppercase',
                      marginBottom: 8,
                    }}
                  >
                    Note to participant
                  </label>
                  <textarea
                    className="pg-textarea"
                    placeholder="Optional feedback for approve / reject / revision"
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    style={{ minHeight: 72 }}
                  />
                </div>
                <div style={{ display: 'flex', gap: 10, marginTop: '1.5rem', flexWrap: 'wrap' }}>
                  <button className="pg-btn-primary" style={{ padding: '10px 20px', fontSize: 13 }} onClick={() => act('approved')}>
                    Approve & award points
                  </button>
                  <button
                    className="pg-btn-secondary"
                    style={{ padding: '10px 20px', fontSize: 13 }}
                    onClick={() => act('revision_requested')}
                  >
                    Request revision
                  </button>
                  <button
                    style={{
                      padding: '10px 20px',
                      fontSize: 13,
                      borderRadius: 8,
                      border: '1px solid rgba(239,68,68,0.4)',
                      background: 'rgba(239,68,68,0.1)',
                      color: 'var(--pg-red)',
                      cursor: 'pointer',
                      fontWeight: 600,
                    }}
                    onClick={() => act('rejected')}
                  >
                    Reject
                  </button>
                </div>
                <p style={{ fontSize: 12, color: 'var(--pg-text-dim)', marginTop: 12 }}>
                  After you decide, the next pending item in this view is selected automatically.
                </p>
              </>
            )}

            {selected.status === 'approved' && selected.pointsAwarded != null && (
              <div style={{ marginTop: '1rem', fontFamily: "'JetBrains Mono', monospace", fontSize: 14, color: 'var(--pg-green)' }}>
                +{selected.pointsAwarded} pts awarded
              </div>
            )}

            <div style={{ display: 'flex', gap: 10, marginTop: '1.5rem', flexWrap: 'wrap' }}>
              <button
                className="pg-btn-secondary"
                style={{ padding: '8px 16px', fontSize: 12 }}
                onClick={() => onNavigate('detail', selected.competitionId)}
              >
                View competition →
              </button>
              <button
                className="pg-btn-secondary"
                style={{ padding: '8px 16px', fontSize: 12 }}
                onClick={() => onNavigate('review', selected.competitionId, { tab: 'all' })}
              >
                All submissions for this comp →
              </button>
            </div>
          </div>
        ) : (
          <div
            style={{
              padding: '3rem',
              textAlign: 'center',
              color: 'var(--pg-text-dim)',
              background: 'var(--pg-mid)',
              border: '1px solid var(--pg-border)',
              borderRadius: 14,
            }}
          >
            Select a submission from the list, or change filters.
          </div>
        )}
      </div>
    </div>
  );
}

function DetailBlock({
  label,
  value,
  highlight,
}: {
  label: string;
  value: string;
  highlight?: boolean;
}) {
  return (
    <div style={{ marginBottom: '1rem' }}>
      <div
        style={{
          fontSize: 10,
          color: 'var(--pg-text-dim)',
          fontFamily: "'JetBrains Mono', monospace",
          textTransform: 'uppercase',
          marginBottom: 6,
        }}
      >
        {label}
      </div>
      <div
        style={{
          fontSize: 14,
          color: highlight ? 'var(--pg-accent-bright)' : 'var(--pg-text-sec)',
          lineHeight: 1.6,
          fontWeight: highlight ? 600 : 400,
        }}
      >
        {value}
      </div>
    </div>
  );
}
